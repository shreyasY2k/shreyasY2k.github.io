const readline = require('readline');

function validateInput(n, type) {
    switch (type) {
        case 'cases':
            if (isNaN(n) || n <= 0 || n > 10 ** 5) {
                return false;
            }
            break;
        case 'seat':
            if (isNaN(n) || n <= 0 || n > 108) {
                return false;
            }
            break;
        default:
            return true
    }
    return true;
}

function findSeatTypeAndFacingSeat(n) {
    const rem = n % 12;

    const offsets = [-11, 11, 9, 7, 5, 3, 1, -1, -3, -5, -7, -9];
    const seatTypes = ['WS', 'WS', 'MS', 'AS', 'AS', 'MS', 'WS', 'WS', 'MS', 'AS', 'AS', 'MS'];

    const offset = offsets[rem];
    const facingSeat = n + offset;
    const seatType = seatTypes[rem];

    return `${facingSeat} ${seatType}`;
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let t;

rl.question('Enter the number of test cases: ', (num) => {
    t = parseInt(num);

    if (!validateInput(t, 'cases')) {
        console.error('Invalid input for the number of test cases.');
        rl.close();
        return;
    }

    function processNextTestCase() {
        if (t > 0) {
            rl.question('Enter the seat number: ', (seatNumber) => {
                const n = parseInt(seatNumber);

                if (!validateInput(n, 'seat')) {
                    console.error('Invalid input for seat number.');
                    rl.close();
                    return;
                }

                const result = findSeatTypeAndFacingSeat(n);
                console.log(result);
                t--;
                processNextTestCase();
            });
        } else {
            rl.close();
        }
    }

    processNextTestCase();
});
